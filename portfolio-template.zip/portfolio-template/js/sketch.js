function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  // background(220);
  clear();
  ellipse(mouseX, mouseY, 20);
}
