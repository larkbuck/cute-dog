function setup() {
  createCanvas(windowWidth, windowHeight);

  fill(146, 214, 164);
  noStroke();
}

function draw() {
  // background(220);
  clear();
  ellipse(mouseX, mouseY, 66); // draws circle at cursor
}
